<!DOCTYPE html>
<html>
    <?php require('0_head.php'); ?>
    <body style="width: 100vw; height: 98vh;">
        
<?php 
    require('db_connect.php'); 
    require('validate.php'); 
?>
    </body>
</html>