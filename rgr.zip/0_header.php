<nav class="uk-navbar-container uk-margin uk-box-shadow-medium" uk-navbar>
    <div class="uk-navbar-center">
        <ul class="uk-navbar-nav">
            <li><a href="https://valtion.ru/index.php">Аренда</a></li>
            <li>
                <a href="https://valtion.ru/2_all_table.php">Таблицы</a>
                <div class="uk-navbar-dropdown">
                   <ul class="uk-nav uk-navbar-dropdown-nav">
                        <li><a href="https://valtion.ru/2_1_clients.php">Клиенты</a></li>
                        <li><a href="https://valtion.ru/2_2_rent.php">Арендуемые площади</a></li>
                        <li><a href="https://valtion.ru/2_3_places.php">Все площади</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="3_about.php">О нас</a></li>
        </ul>
    </div>
</nav>